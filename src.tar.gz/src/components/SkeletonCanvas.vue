<template>
  <div class="wrap">
    <video ref="videoRef" class="feed" autoplay playsinline muted />
    <canvas ref="canvasRef" :width="props.width" :height="props.height" />

    <div class="hud">
      <span class="badge" :class="{ active: isRunning }">
        {{ isRunning ? '● LIVE' : '○ STOPPED' }}
      </span>
      <span class="badge">{{ fps }} fps</span>
      <span class="badge">{{ poseScore }}</span>
      <button @click="toggleRun">{{ isRunning ? 'Stop' : 'Start' }}</button>
    </div>

    <div v-if="captureError || error" class="error-banner">
      {{ captureError ?? error }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, shallowRef } from 'vue'
import { useSkeleton, BONES } from '../composables/useSkeleton'

const props = withDefaults(defineProps<{
  width?:  number
  height?: number
}>(), {
  width:  1280,
  height: 720,
})

const videoRef    = ref<HTMLVideoElement | null>(null)
const canvasRef   = ref<HTMLCanvasElement | null>(null)
const captureError = ref<string | null>(null)
const fps         = ref(0)
const poseScore   = ref('no pose')
const gpuSupported = ref(true);

const { frame, isRunning, error, init, attachVideo, start, stop } = useSkeleton()
//--- Camera -------------------------
async function toggleRun() {
  if (isRunning.value) { stop(); return }
  await startCapture()
}

async function startCapture() {
  if (!videoRef.value) return
  captureError.value = null
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true })
    videoRef.value.srcObject = stream
    await new Promise<void>(res => { videoRef.value!.onloadedmetadata = () => res() })
    attachVideo(videoRef.value)
    start()
  } catch (e: any) {
    captureError.value = `Camera error: ${e?.name} — ${e?.message}`
  }
}

//--- GPU ----------------------------
const gpu = shallowRef<any>(null);

async function initGPU(){
  if(!navigator.gpu){
    gpuSupported.value = false;
    return;
  }
  const adapter = await navigator.gpu.requestAdapter()
  const device = await adapter!.requestDevice()
  console.log('loaded gpu device')
  const canvas = canvasRef.value

  let gl = canvas?.getContext('webgl')
  if(gl){
    console.log("WEBGL2 supported")
  }else{
    console.error("WebGL2 not supported!")
    //TODO: handle this later
    return;
  }

  const format = navigator.gpu.getPreferredCanvasFormat()
  gl.configure()
}


// Deliberately simple: draw joints as circles and bones as lines.
// No WebGPU, no buffers, no shaders — just confirm the data is right first.

let rafId: number | null = null
let lastFpsTime = performance.now()
let frameCount  = 0
let lastTimestamp = -1

// function renderLoop() {
//   rafId = requestAnimationFrame(renderLoop)

//   const canvas = canvasRef.value
//   const f      = frame.value
//   if (!canvas) return

//   const ctx = canvas.getContext('2d')!
//   const W   = canvas.width
//   const H   = canvas.height

//   // FPS
//   frameCount++
//   const now = performance.now()
//   if (now - lastFpsTime >= 500) {
//     fps.value   = Math.round(frameCount / ((now - lastFpsTime) / 1000))
//     frameCount  = 0
//     lastFpsTime = now
//   }

//   // clear
//   ctx.fillStyle = '#0a0a14'
//   ctx.fillRect(0, 0, W, H)

//   if (!f || f.timestamp === lastTimestamp) return
//   lastTimestamp = f.timestamp


//   const kps = f.keypoints

//   // draw bones
//   ctx.strokeStyle = 'rgba(100, 180, 255, 0.7)'
//   ctx.lineWidth   = 3
//   for (const [a, b] of BONES) {
//     const ka = kps[a]
//     const kb = kps[b]
//     if (!ka || !kb) continue
//     if (ka.visibility < 0.3 || kb.visibility < 0.3) continue
//     ctx.beginPath()
//     ctx.moveTo(ka.x * W, ka.y * H)
//     ctx.lineTo(kb.x * W, kb.y * H)
//     ctx.stroke()
//   }

//   // draw joints
//   for (const kp of kps) {
//     if (kp.visibility < 0.3) continue
//     const x = kp.x * W
//     const y = kp.y * H
//     const r = 6 + kp.visibility * 4

//     // glow
//     const grad = ctx.createRadialGradient(x, y, 0, x, y, r * 2)
//     grad.addColorStop(0,   'rgba(100, 220, 255, 0.9)')
//     grad.addColorStop(0.4, 'rgba(100, 180, 255, 0.4)')
//     grad.addColorStop(1,   'rgba(100, 180, 255, 0)')
//     ctx.fillStyle = grad
//     ctx.beginPath()
//     ctx.arc(x, y, r * 2, 0, Math.PI * 2)
//     ctx.fill()

//     // core dot
//     ctx.fillStyle = '#ffffff'
//     ctx.beginPath()
//     ctx.arc(x, y, 4, 0, Math.PI * 2)
//     ctx.fill()
//   }

//   // show best keypoint score in HUD
//   const best = kps.reduce((a, b) => b.visibility > a.visibility ? b : a, kps[0])
//   poseScore.value = `conf: ${best?.visibility.toFixed(2) ?? '—'}`
// }

onMounted(async () => {
  await init()
  await initGPU()
  //renderLoop()
})

onUnmounted(() => {
  if (rafId) cancelAnimationFrame(rafId)
  stop()
})
</script>

<style scoped>
.wrap {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 9;
  background: #0a0a14;
  border-radius: 8px;
  overflow: hidden;
}

.feed {
  position: absolute;
  width: 1px; height: 1px;
  opacity: 0;
  pointer-events: none;
}

canvas {
  width: 100%;
  height: 100%;
  display: block;
}

.hud {
  position: absolute;
  top: 12px; left: 12px;
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.badge {
  font-family: monospace;
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 4px;
  background: rgba(255,255,255,0.08);
  color: #aaa;
}
.badge.active { color: #4eff9e; background: rgba(78,255,158,0.12); }

button {
  font-size: 12px;
  padding: 4px 14px;
  border-radius: 4px;
  border: 1px solid rgba(255,255,255,0.15);
  background: rgba(255,255,255,0.07);
  color: #eee;
  cursor: pointer;
}
button:hover { background: rgba(255,255,255,0.14); }

.error-banner {
  position: absolute;
  bottom: 12px; left: 12px; right: 12px;
  padding: 8px 12px;
  background: rgba(220,60,60,0.85);
  color: #fff;
  border-radius: 6px;
  font-size: 13px;
}
</style>