<template>
  <div class="wrap">
    <video ref="videoRef" class="feed" autoplay playsinline muted />
    <canvas ref="simCanvasRef" :width="props.width" :height="props.height"/>


    <!-- <div class="hud">
      <span class="badge" :class="{ active: isRunning }">
        {{ isRunning ? 'LIVE' : 'STOPPED' }}
      </span>
      <span class="badge">{{ fps }} fps</span>
      <span class="badge">{{ poseScore }}</span>
      <button @click="toggleRun">{{ isRunning ? 'Stop' : 'Start' }}</button>
    </div>

    <div v-if="captureError || error" class="error-banner">
      {{ captureError ?? error }}
    </div> -->
  </div>
</template>

<script setup lang="ts">
import { useSkeleton, BONES } from '../composables/useSkeleton'
import {ref, onMounted, onUnmounted, shallowRef } from 'vue'
import { Keypoint } from '@tensorflow-models/pose-detection';
import { createSPHState, SPHState } from '../sim/fluid/state';
import { sim } from '../sim/fluid-sim';
import { disposeRenderer, draw, initRenderer, uploadPositions } from '../webgl/render';
import { spawn } from '../sim/fluid/spawn';

let state: SPHState;

let lastTime = performance.now();
const FIXED_DT = 1/60;
const MAX_SUBSTEPS = 5;

let accumulator = 0;
let rafId = 0;



const props = withDefaults(defineProps<{
    width?: number,
    height?: number
}>(), {
    width: 1280,
    height: 720
});


const gpuSupported = ref(true)
const simCanvasRef = ref<HTMLCanvasElement | null>(null);

onMounted(async() => {
    initRenderer(simCanvasRef.value!);
    state = createSPHState();
    lastTime  = performance.now();
    rafId = requestAnimationFrame(tick)
});

function spawnTestParticles() {
    const PER_FRAME = 4;
    for (let i = 0; i < PER_FRAME; i++) {
        const x = (Math.random() - 0.5) * 0.1;// small horizontal jitter near center
        const y = 0.9; // top of domain
        const vx = (Math.random() - 0.5) * 0.2;
        const vy = -0.5; // initial downward velocity
        const lifetime = 5.0;
        spawn(state, x, y, vx, vy, lifetime);
    }
}

/**
 * tick funciton to pass in same time delta for tuned params.
 * @param now - number
 */
function tick(now:number){
    const elapsed = (now - lastTime)/1000;
    lastTime = now;
    accumulator += Math.min(elapsed, 0.1);

    spawnTestParticles();

    //break delta into substeps
    let substeps = 0;
    while(accumulator >= FIXED_DT && substeps < MAX_SUBSTEPS){
        sim(state, FIXED_DT);
        accumulator -= FIXED_DT;
        substeps++;
    }

    uploadPositions(state.positions, state.activeCount);
    draw(state.activeCount);

    rafId = requestAnimationFrame(tick)
}

onUnmounted(() => {
  cancelAnimationFrame(rafId)
  disposeRenderer()
})


</script>
