<template>
<canvas ref="testCanvasRef" :width="props.width" :height="props.height"/>

</template>
<script setup lang="ts">
import {ref, onMounted, onUnmounted, shallowRef } from 'vue'
import { mat4 } from 'gl-matrix';

const props = withDefaults(defineProps<{
    width?: number,
    height?: number
}>(), {
    width: 1280,
    height: 720
});

const gpuSupported = ref(true);

async function initGPU(){
    if(!navigator.gpu){
        gpuSupported.value = false
        console.log("gpu not supported");
        return
    }
    const canvas = testCanvasRef.value
    if(!canvas){
        console.error("canvas not found")
        return
    }

    const gl = canvas.getContext("webgl2") as WebGL2RenderingContext

    if(gl === null){
        alert("Cannot init WebGL")
        return
    }

    gl.clearColor(0.0, 0.0, 0.0, 1.0)
    gl.clear(gl.COLOR_BUFFER_BIT)


    //vertex shader, receives attribute aVertexPosition
    const vsSource: string = `
        attribute vec4 aVertexPosition;
        attribute vec4 aVertexColor;

        uniform mat4 uModelViewMatrix;
        uniform mat4 uProjectionMatrix;

        varying lowp vec4 vColor;

        void main() {
            gl_Position = uProjectionMatrix * uModelViewMatrix * aVertexPosition;
            vColor = aVertexColor;
        }
    `;

    const fsSource: string = `
        varying lowp vec4 vColor;

        void main(void){
            gl_FragColor = vColor;
        }
    `;



    const shaderProgram = initShaderProgram(gl, vsSource, fsSource);
    if(!shaderProgram){
        return;
    }

    const programInfo = {
        program: shaderProgram,
        attribLocations: {
            vertexPosition: gl.getAttribLocation(shaderProgram, "aVertexPosition"),
            vertexColor: gl.getAttribLocation(shaderProgram, "aVertexColor"),
        },
        uniformLocations: {
            projectionMatrix: gl.getUniformLocation(shaderProgram, "uProjectionMatrix"),
            modelViewMatrix: gl.getUniformLocation(shaderProgram, "uModelViewMatrix")
        },
    };

    const buffers = initBuffers(gl);
    let deltaTime = 0;
    let pyramidRotation = 0.0;
    let then = 0

    function render(now) {
        now *= 0.0001;
        deltaTime = now - then;
        then = now;

        drawScene(gl, programInfo, buffers, pyramidRotation);
        pyramidRotation += (deltaTime*5);

        requestAnimationFrame(render);

    }

    requestAnimationFrame(render)


}

const testCanvasRef = ref<HTMLCanvasElement | null>(null)
onMounted(async() => {
    await initGPU();
})

function initColorsBuffer(gl) {
    const vertexColors = [
        [1.0, 1.0, 1.0, 1.0],  // 0 - apex
        [1.0, 0.0, 0.0, 1.0],  // 1 - front-right
        [0.0, 1.0, 0.0, 1.0],  // 2 - front-left
        [0.0, 0.0, 1.0, 1.0],  // 3 - back-left
        [1.0, 1.0, 0.0, 1.0],  // 4 - back-right
    ];

    let colors = vertexColors.flat();

    const colorBuffer  = gl.createBuffer();

    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

    return colorBuffer;
}
function initShaderProgram(gl: WebGL2RenderingContext, vsSource:string, fsSource:string): WebGLProgram|void{
    const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource)
    const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource)
    if(!vertexShader || !fragmentShader) return;

    const shaderProgram: WebGLProgram = gl.createProgram()
    gl.attachShader(shaderProgram, vertexShader)
    gl.attachShader(shaderProgram, fragmentShader)

    gl.linkProgram(shaderProgram);

    if(!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)){
        alert(`unable to init shader program: ${gl.getProgramInfoLog(shaderProgram)}`,);
        return;
    }

    return shaderProgram;


}

function loadShader(gl: WebGL2RenderingContext, type:  number, source:string): WebGLShader|void{
    const shader = gl.createShader(type);
    if(!shader) return;

    gl.shaderSource(shader, source);

    gl.compileShader(shader);
    if(!gl.getShaderParameter(shader, gl.COMPILE_STATUS)){
        alert(`An error occurred compiling shaders: ${gl.getShaderInfoLog(shader)}`)
        gl.deleteShader(shader);
        return;
    }
    return shader
}

function initBuffers(gl: WebGL2RenderingContext) :  any {
    const positionBuffer = initPositionBuffer(gl);
    const colorBuffer = initColorsBuffer(gl);
    const indexBuffer = initIndexBuffer(gl);

    return {
        position: positionBuffer,
        color: colorBuffer,
        indices: indexBuffer
    };
}


function initPositionBuffer(gl: WebGL2RenderingContext){
    //create buffer for triangle position
    const positionBuffer = gl.createBuffer();

    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    //    /\
    //   /  \
    //  /____\
    const positions = [
        // 5 unique vertices
        0.0,  1.0,  0.0,  // 0 - apex
        1.0, -1.0,  1.0,  // 1 - front-right base
        -1.0, -1.0,  1.0,  // 2 - front-left base
        -1.0, -1.0, -1.0,  // 3 - back-left base
        1.0, -1.0, -1.0,  // 4 - back-right base
    ];

     gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);

     return positionBuffer;
}

function initIndexBuffer(gl){
    const indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);

    const indices = [
        0, 1, 2,  // front face
        0, 4, 3,  // back face
        0, 2, 3,  // left face
        0, 4, 1,  // right face
        1, 2, 3,  // base triangle 1
        1, 3, 4,  // base triangle 2
    ];

    gl.bufferData(
        gl.ELEMENT_ARRAY_BUFFER,
        new Uint16Array(indices),
        gl.STATIC_DRAW,
    );

    return indexBuffer;
}

function setColorAttribute(gl, buffers, programInfo) {
    const numComponents = 4;
    const type = gl.FLOAT;
    const normalize = false;
    const stride = 0;
    const offset = 0;
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.color);
    gl.vertexAttribPointer(
        programInfo.attribLocations.vertexColor,
        numComponents,
        type,
        normalize,
        stride,
        offset,
    );
    gl.enableVertexAttribArray(programInfo.attribLocations.vertexColor);
}

function drawScene(gl: WebGL2RenderingContext, programInfo: any, buffers, pyramidRotation){
    gl.clearColor(0.0, 0.0, 0.0,1.0);
    gl.clearDepth(1.0) //clear everything?
    gl.enable(gl.DEPTH_TEST);//enable depth testing?
    gl.depthFunc(gl.LEQUAL);//near obscure far things

    //clear canvas before drawing
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT) 
    const fieldOfView = (45 * Math.PI)/180; //in radians

    const aspect = gl.canvas.width / gl.canvas.height

    const zNear = 0.1;
    const zFar = 100.0;

    const projectionMatrix = mat4.create();

    mat4.perspective(projectionMatrix, fieldOfView, aspect, zNear, zFar);

    //
    const modelViewMatrix = mat4.create();

    mat4.translate(
        modelViewMatrix,
        modelViewMatrix,
        [-0.0, 0.0, -6.0]
    );

    console.log("rotating", pyramidRotation, "radians")
    mat4.rotate(
        modelViewMatrix, //dest matrix
        modelViewMatrix, //matrix to rotate
        pyramidRotation, //amount to rotate (radians)
        [0, 0, 1] //axis to rotate around
    );
    mat4.rotate(
        modelViewMatrix, //dest matrix
        modelViewMatrix, //matrix to rotate
        pyramidRotation * 0.7, //amount to rotate (radians)
        [0, 1, 0] //axis to rotate around
    );
    mat4.rotate(
        modelViewMatrix, //dest matrix
        modelViewMatrix, //matrix to rotate
        pyramidRotation * 0.3, //amount to rotate (radians)
        [1, 0, 0] //axis to rotate around
    );

    
    setPositionAttribute(gl, buffers, programInfo);
    setColorAttribute(gl, buffers, programInfo);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.indices);
    gl.useProgram(programInfo.program);
    
    gl.uniformMatrix4fv(
        programInfo.uniformLocations.projectionMatrix,
        false,
        projectionMatrix
    );
    gl.uniformMatrix4fv(
        programInfo.uniformLocations.modelViewMatrix,
        false,
        modelViewMatrix
    )
    {
        const vertexCount = 18;
        const type = gl.UNSIGNED_SHORT;
        const offset = 0;
        gl.drawElements(gl.TRIANGLES, vertexCount, type, offset);
    }
    // {
    //     const offset = 0;
    //     const vertexCount = 3;
    //     gl.drawArrays(gl.TRIANGLE_STRIP, offset, vertexCount);
    // }
}


function setPositionAttribute(gl: WebGL2RenderingContext, buffers:any, programInfo:any){
    const numComponents = 3;
    const type = gl.FLOAT;
    const normalize = false;

    const stride = 0;

    const offset = 0;

    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.position);
    gl.vertexAttribPointer(
        programInfo.attribLocations.vertexPosition,
        numComponents,
        type,
        normalize,
        stride,
        offset
    )

    gl.enableVertexAttribArray(programInfo.attribLocations.vertexPosition);
}


</script>
