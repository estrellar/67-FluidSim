<script setup lang="ts">
// import SkeletonCanvas from "./components/SkeletonCanvas.vue";
import TestCanvas from "./components/TestCanvas.vue";
import SimCanvas from "./components/SimCanvas.vue";
</script>
<template>
  <!-- <SkeletonCanvas :width="1280" :height="720" /> -->
   <SimCanvas :width="720" :height="720"/>
   <TestCanvas :width="720" :height="720"/>
</template>