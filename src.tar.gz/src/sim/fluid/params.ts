//adjustable params for 
export const params = {
    spawnRate: 30.0,
    stiffness: 0.5,
    stiffnessNear: 0.5,
    restDensity: 5.0,
    alpha: 0.1,
    beta: 0.0,
    gravity: -9.8,
};