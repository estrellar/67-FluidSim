export const GRID_SIZE = 0.1;
export const SMOOTHING_RADIUS = 0.09;
export const GRID_COUNT = Math.ceil(2.0 / GRID_SIZE);

export const MAX_PARTICLES = 2000;
